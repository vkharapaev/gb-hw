package javacore.advanced.hw4.task2.android.ui;

public interface BaseView<T> {

}
